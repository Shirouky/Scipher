<template>
  <div>
    <div class="head">
      <div class="head_container">
        <div>
          <div class="subheader">
            <div class="tegs">
              <ArticleTeg :tegs="tegs" />
              <i class="fas fa-plus fa-xs"></i>
            </div>
            <p id="header" class="date">{{ date }}{{ changed }}</p>
          </div>
          <input
            v-model="header"
            class="label"
            type="text"
            placeholder="Введите название статьи..."
          />
        </div>
      </div>
    </div>
    <div class="editor">
      <ckeditor
        v-model="editorData"
        :config="editorConfig"
        id="editor"
      ></ckeditor>
      <button @click="save">Save</button>
    </div>
  </div>
</template>

<script>
import ArticleTeg from "@/components/ArticleTeg.vue";

export default {
  name: "ArticleEditView",
  components: {
    ArticleTeg,
  },
  props: {
    language: String,
  },
  beforeDestroy() {
    this.save();
    this.header = null;
    delete this.header;
  },
  methods: {
    emptyEditor() {
      this.editorData = "";
    },
    save() {
      console.log(this.editorData);
    },
  },
  data() {
    return {
      tegs: [
        {
          id: 1,
          text: {
            en: "Moscow",
            ru: "Москва",
          },
          color: "#F3CDDB",
        },
        {
          id: 2,
          text: {
            en: "Mary Kury",
            ru: "Мария",
          },
          color: "#B0EADF",
        },
        {
          id: 5,
          text: {
            en: "Moscow",
            ru: "Москва",
          },
          color: "#F3CDDB",
        },
        {
          id: 6,
          text: {
            en: "Mary Kury",
            ru: "Мария",
          },
          color: "#B0EADF",
        },
        {
          id: 7,
          text: {
            en: "Mary Kury",
            ru: "Мария",
          },
          color: "#B0EADF",
        },
        {
          id: 8,
          text: {
            en: "Mary Kury",
            ru: "Мария",
          },
          color: "#B0EADF",
        },
      ],
      tegs_display: [],
      shorten: true,
      display: "none",
      header: "",
      text: "",
      editorData: "",
      changed: " (изменено)",
      date: "18.02.21",
      editorConfig: {
        toolbar: [
          {
            name: "document",
            groups: ["mode", "document", "doctools"],
            items: [
              "-",
              "Save",
              "NewPage",
              "ExportPdf",
              "Preview",
              "Print",
              "-",
              "Templates",
            ],
          },
          {
            name: "clipboard",
            groups: ["clipboard", "undo"],
            items: ["Cut", "Copy", "Paste", "Undo", "Redo"],
          },
          {
            name: "editing",
            groups: ["find", "selection", "spellchecker"],
            items: ["Find", "Replace", "-", "SelectAll", "-", "Scayt"],
          },
          {
            name: "forms",
            items: [
              "Form",
              "Checkbox",
              "Radio",
              "TextField",
              "Textarea",
              "Select",
              "Button",
              "ImageButton",
              "HiddenField",
            ],
          },
          {
            name: "basicstyles",
            groups: ["basicstyles", "cleanup"],
            items: [
              "Bold",
              "Italic",
              "Underline",
              "Strike",
              "Subscript",
              "Superscript",
              "-",
              "CopyFormatting",
              "RemoveFormat",
            ],
          },
          {
            name: "paragraph",
            groups: ["list", "indent", "blocks", "align", "bidi"],
            items: [
              "NumberedList",
              "BulletedList",
              "-",
              "Outdent",
              "Indent",
              "-",
              "Blockquote",
              "CreateDiv",
              "-",
              "JustifyLeft",
              "JustifyCenter",
              "JustifyRight",
              "JustifyBlock",
              "-",
              "BidiLtr",
              "BidiRtl",
              "Language",
            ],
          },
          {
            name: "insert",
            items: [
              "Image",
              "Table",
              "HorizontalRule",
              "Smiley",
              "SpecialChar",
              "PageBreak",
              "Iframe",
            ],
          },
          { name: "styles", items: ["Styles", "Format", "Font", "FontSize"] },
          { name: "colors", items: ["TextColor", "BGColor"] },
          { name: "tools", items: ["Maximize", "ShowBlocks"] },
          { name: "others", items: ["-"] },
        ],
        removePlugins: "elementspath",
        width: "80vw",
        toolbarCanCollapse: true,
      },
    };
  },
};
</script>

<style scoped lang="scss" src="../assets/scss/article_edit.scss"></style>
