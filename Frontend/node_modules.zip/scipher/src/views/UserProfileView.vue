<template>
  <div>
    <ShortenedHeader />
    <div class="head"><FullUser :user="user" /></div>
    <figure class="tabBlock">
      <ul class="tabBlock-tabs">
        <li :aria-setsize="tabs.length" :aria-posinet="1">
          <a
            href="#home"
            class="tabBlock-tab"
            :class="active_tab === 0 ? 'is-active' : ''"
            :aria-selected="active_tab === 0"
            @click="changeTab(0)"
          >
            <i class="fa fa-home"></i>
            <strong>Главная</strong>
          </a>
        </li>
        <div v-if="user.id === Number(this.$cookies.get('id'))">
          <li
            v-for="(tab, index) in tabs"
            :key="index + 1"
            :aria-setsize="tabs.length + 1"
            :aria-posinet="index + 1"
          >
            <a
              :href="'#' + tab.href"
              class="tabBlock-tab"
              :class="active_tab === index + 1 ? 'is-active' : ''"
              :aria-selected="active_tab === index + 1"
              @click="changeTab(index + 1)"
            >
              <i :class="tab.tab_icon"></i>
              <strong>{{ tab.tab_title }}</strong>
            </a>
          </li>
        </div>
      </ul>
      <div class="tabBlock-content">
        <div
          name="home"
          :aria-current="active_tab === 0"
          class="tabBlock-pane"
          v-show="active_tab === 0"
        >
          <div class="home">
            <div class="left">
              <h3>Описание</h3>
              <div class="description">
                <p>{{ user.description }}</p>
              </div>
              <h3>Статьи пользователя</h3>
              <ShortenedArticle
                v-for="article in user.authorship"
                :key="article.id"
                :article="article"
              />
            </div>
            <div class="right">
              <h3>Информация о пользователе</h3>
              <div class="info">
                <ul>
                  <li>
                    <p>День рождения:</p>
                    <span>{{ user.date_of_birth }}</span>
                  </li>
                  <li>
                    <p>Последняя активность:</p>
                    <span>{{ user.date_added }}</span>
                  </li>
                  <li>
                    <p>Настоящее имя:</p>
                    <span>{{ user.first_name }} {{ user.second_name }}</span>
                  </li>
                  <li>
                    <p>Email:</p>
                    <span>{{ user.email }}</span>
                  </li>
                  <li>
                    <p>На сайте с:</p>
                    <span>{{ user.date_added }}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div
          :aria-current="active_tab === 1"
          class="tabBlock-pane"
          v-show="active_tab === 1"
          name="articles"
        >
          <figure class="tabBlock">
            <ul class="tabBlock-tabs">
              <li :aria-setsize="article_tabs.length" :aria-posinet="index + 1">
                <a
                  class="tabBlock-tab"
                  :class="active_article_tab === 0 ? 'is-active' : ''"
                  :aria-selected="active_article_tab === 0"
                  @click="changeArticleTab(0)"
                >
                  <strong>{{ article_tabs[0] }}</strong>
                </a>
                <a
                  class="tabBlock-tab"
                  :class="active_article_tab === 1 ? 'is-active' : ''"
                  :aria-selected="active_article_tab === 1"
                  @click="changeArticleTab(1)"
                >
                  <strong>{{ article_tabs[1] }}</strong>
                </a>
                <label
                  for="slct"
                  class="tabBlock-tab select"
                  :class="active_article_tab === 2 ? 'is-active' : ''"
                  :aria-selected="active_article_tab === 2"
                  @click="changeArticleTab(2)"
                >
                  <select id="slct" required="required" v-model="option">
                    <option value="" disabled="disabled" selected="selected">
                      Select option
                    </option>
                    <option
                      v-for="(compilation, index) in compilations"
                      :key="compilation.id"
                      :value="index"
                    >
                      {{ compilation.title }}
                    </option>
                  </select>
                </label>
              </li>
            </ul>
            <div class="tabBlock-content">
              <div
                name="read"
                :aria-current="active_article_tab === 0"
                class="tabBlock-pane"
                v-show="active_article_tab === 0"
              >
                <div class="home">
                  <ShortenedArticle
                    v-for="article in read"
                    :key="article.id"
                    :article="article"
                  />
                </div>
              </div>
            </div>
            <div class="tabBlock-content">
              <div
                name="viewed"
                :aria-current="active_article_tab === 1"
                class="tabBlock-pane"
                v-show="active_article_tab === 1"
              >
                <div class="home">
                  <ShortenedArticle
                    v-for="article in viewed"
                    :key="article.id"
                    :article="article"
                  />
                </div>
              </div>
            </div>
            <div class="tabBlock-content">
              <div
                name="personal"
                :aria-current="active_article_tab === 2"
                class="tabBlock-pane"
                v-show="active_article_tab === 2"
              >
                <div class="home">
                  <ShortenedArticle
                    v-for="article in compilations[option].articles"
                    :key="article.id"
                    :article="article"
                  />
                </div>
              </div>
            </div>
          </figure>
        </div>
        <div
          :aria-current="active_tab === 2"
          class="tabBlock-pane"
          v-show="active_tab === 2"
          name="comments"
        >
          <div class="home">
            <Comment
              v-for="comment in comments"
              :key="comment.id"
              :comment="comment"
            />
          </div>
        </div>
        <div
          :aria-current="active_tab === 3"
          class="tabBlock-pane"
          v-show="active_tab === 3"
          name="settings"
        >
          <p>Я хочу быть автором</p>
          <input type="checkbox" @click="getUserData()" />
          <p>Изменить логин<i class="fa fa-edit"></i></p>
          <p>Изменить пароль</p>
          <i class="fa fa-pencil"></i>
          <p>Изменить логин</p>
          <i class="fa fa-pencil"></i>
        </div>
      </div>
    </figure>
  </div>
</template>




<script>
import ShortenedHeader from "@/components/ShortenedHeader.vue";
import ShortenedArticle from "@/components/ShortenedArticle.vue";
import FullUser from "@/components/FullUser.vue";
import Comment from "@/components/Comment.vue";

export default {
  name: "UserProfileView",
  components: {
    FullUser,
    ShortenedHeader,
    ShortenedArticle,
    Comment,
  },
  created(){

  },
  mounted() {
    const values = {
      "#home": 0,
      "#articles": 1,
      "#comments": 2,
      "#settings": 3,
    };
    setTimeout(() => this.changeTab(values[this.$route.hash]), 1);
  },
  methods: {
    changeTab(tabIndexValue) {
      if (
        tabIndexValue != 0 &&
        this.$cookies.get("id") == this.$route.params.id || tabIndexValue == 0
      ) {
        this.active_tab = tabIndexValue;
      }
    },
    changeArticleTab(tabIndexValue) {
      this.active_article_tab = tabIndexValue;
    },
    getUserData() {
      // this.axios
      //   .get("/user/", {
      //     params: {
      //       id: this.$router.params.id,
      //     },
      //   })
      //   .then(function (response) {
      //     this.user = response.data;
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
    },
    getSavedArticles() {
      // this.axios
      //   .get("/user/articles", {
      //     params: {
      //       id: this.$router.params.id,
      //     },
      //   })
      //   .then(function (response) {
      //     this.viewed = response.data.viewed;
      //     this.read = response.data.read;
      //     this.compilations = response.data.compilations;
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
    },
    getComments() {
      // this.axios
      //   .get("/user/comments", {
      //     params: {
      //       id: this.$router.params.id,
      //     },
      //   })
      //   .then(function (response) {
      //     this.comments = response.data;
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
    },
  },
  data() {
    return {
      option: 0,
      index: 0,
      active_tab: 0,
      active_article_tab: 0,
      article_tabs: ["Прочитанные", "Просмотренные"],
      compilations: [
        {
          id: 1,
          title: "fsfse",
          description: "sfsfsfs",
          articles: [
            {
              id: 1,
              views: 300004,
              date_added: "21.04.2020",
              title: "article 1",
              rating: 5,
              description:
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
              period_start: "23.04.2020",
              period_end: "25.04.2020",
              color: "white",
              background_color: "rgba(18, 0, 0, 0.8)",
              background_img:
                "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
              author: {
                id: 2,
                username: "Author",
                avatar:
                  "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
              },
              tegs: [
                {
                  id: 1,
                  text: {
                    en: "Moscow",
                    ru: "Москва",
                  },
                  background_color: "#F3CDDB",
                  text_color: "black",
                },
                {
                  id: 2,
                  text: {
                    en: "Mary Kury",
                    ru: "Мария",
                  },
                  background_color: "#B0EADF",
                  text_color: "black",
                },
                {
                  id: 5,
                  text: {
                    en: "Moscow",
                    ru: "Москва",
                  },
                  background_color: "#F3CDDB",
                  text_color: "black",
                },
              ],
            },
          ],
        },
        {
          id: 2,
          title: "fssfgfgfse",
          description: "sfssfsffsfs",
          articles: [
            {
              id: 2,
              views: 3004,
              date_added: "21.04.2020",
              title: "article 2",
              rating: 5,
              description:
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
              period_start: "23.04.2020",
              period_end: "25.04.2020",
              color: "white",
              background_color: "rgba(18, 0, 0, 0.8)",
              background_img:
                "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
              author: {
                id: 2,
                username: "Author",
                avatar:
                  "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
              },
              tegs: [
                {
                  id: 1,
                  text: {
                    en: "Moscow",
                    ru: "Москва",
                  },
                  background_color: "#F3CDDB",
                  text_color: "black",
                },
                {
                  id: 2,
                  text: {
                    en: "Mary Kury",
                    ru: "Мария",
                  },
                  background_color: "#B0EADF",
                  text_color: "black",
                },
                {
                  id: 5,
                  text: {
                    en: "Moscow",
                    ru: "Москва",
                  },
                  background_color: "#F3CDDB",
                  text_color: "black",
                },
              ],
            },
          ],
        },
      ],
      comments: [
        {
          id: 1,
          text: "dsdsdasdsdasd",
          likes: 23,
          date_added: "12.03.2100",
          article: {
            id: 1,
            title: "sdfsfs",
          },
          author: {
            id: 2,
            username: "cacs",
            avatar:
              "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
          },
        },
        {
          id: 2,
          text: "dsdsdasdsdasd",
          likes: 23,
          date_added: "12.03.2100",
          author: {
            id: 2,
            name: "cacs",
            avatar:
              "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
          },
        },
      ],
      tabs: [
        {
          tab_title: "Сохраненные статьи",
          tab_icon: "fa fa-bookmark",
          href: "articles",
        },
        {
          tab_title: "Комментарии",
          tab_icon: "fa fa-comments",
          href: "comments",
        },
        {
          tab_title: "Настройки",
          tab_icon: "fa fa-cogs",
          href: "settings",
        },
      ],
      viewed: [
        {
          id: 1,
          views: 300004,
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            username: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
          ],
        },
      ],
      read: [
        {
          id: 1,
          views: 300004,
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            username: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
          ],
        },
      ],
      user: {
        id: 1,
        text_color: "white",
        background_color: "rgba(18, 0, 0, 0.8)",
        avatar:
          "https://w-dog.ru/wallpapers/0/62/349856802100204/zolotoj-bereg-okean-avstraliya-oteli-more-gorod.jpg",
        background_img:
          "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
        username: "user 1",
        rating: 5.98,
        is_active: true,
        first_name: "adad",
        second_name: "asdadsd",
        email: "asdadd",
        date_added: "13.02.2022",
        date_of_birth: "13.02.2022",
        last_activity: "13.02.2022",
        description:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.",
        authorship: [
          {
            id: 1,
            views: 300004,
            date_added: "21.04.2020",
            title: "article 1",
            rating: 5,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
            period_start: "23.04.2020",
            period_end: "25.04.2020",
            color: "white",
            background_color: "rgba(18, 0, 0, 0.8)",
            background_img:
              "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
            author: {
              id: 2,
              username: "Author",
              avatar:
                "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
            },
            tegs: [
              {
                id: 1,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 2,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 5,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 6,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 7,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 8,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
            ],
          },
          {
            id: 2,
            views: 300004,
            date_added: "21.04.2020",
            title: "article 1",
            rating: 5,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
            period_start: "23.04.2020",
            period_end: "25.04.2020",
            color: "white",
            background_color: "rgba(18, 0, 0, 0.8)",
            background_img:
              "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
            author: {
              id: 2,
              username: "Author",
              avatar:
                "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
            },
            tegs: [
              {
                id: 1,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 2,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 5,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 6,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 7,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 8,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
            ],
          },
          {
            id: 3,
            views: 300004,
            date_added: "21.04.2020",
            title: "article 1",
            rating: 5,
            description:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
            period_start: "23.04.2020",
            period_end: "25.04.2020",
            color: "white",
            background_color: "rgba(18, 0, 0, 0.8)",
            background_img:
              "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
            author: {
              id: 2,
              username: "Author",
              avatar:
                "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
            },
            tegs: [
              {
                id: 1,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 2,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 5,
                text: {
                  en: "Moscow",
                  ru: "Москва",
                },
                background_color: "#F3CDDB",
                text_color: "black",
              },
              {
                id: 6,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 7,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
              {
                id: 8,
                text: {
                  en: "Mary Kury",
                  ru: "Мария",
                },
                background_color: "#B0EADF",
                text_color: "black",
              },
            ],
          },
        ],
      },
    };
  },
};
</script>

<style scoped lang="scss" src="../assets/scss/user_profile.scss"></style>
