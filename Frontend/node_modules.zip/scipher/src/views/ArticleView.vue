<template>
  <div>
    <ShortenedHeader />
    <div class="head">
    <FullArticle :article="article" />
    </div>
    <div class="home">
      <div class="article" id="article"></div>
      <hr />
      <div class="home">
        <Comment
          v-for="comment in comments"
          :key="comment.id"
          :comment="comment"
        />
      </div>
    </div>
  </div>
</template>

<script>
import ShortenedHeader from "@/components/ShortenedHeader.vue";
import FullArticle from "@/components/FullArticle.vue";
import Comment from "@/components/Comment.vue";

export default {
  name: "ArticleView",
  components: {
    ShortenedHeader,
    FullArticle,
    Comment,
  },
  props: {},
  mounted() {
    this.setArticleData();
  },
  methods: {
    setArticleData() {
      const article = document.getElementById("article");
      article.innerHTML = this.article.text;
    },
  },
  data() {
    return {
      comments: [
        {
          id: 1,
          text: "dsdsdasdsdasd",
          likes: 23,
          date_added: "12.03.2100",
          author: {
            id: 2,
            username: "cacs",
            avatar:
              "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
          },
        },
        {
          id: 2,
          text: "dsdsdasdsdasd",
          likes: 23,
          date_added: "12.03.2100",
          author: {
            id: 2,
            username: "cacs",
            avatar:
              "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
          },
        },
      ],
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.",
      article: {
        id: 1,
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas posuere, urna ut malesuada pulvinar, sem arcu scelerisque felis, vitae vulputate ex quam vitae urna. Nullam semper cursus vestibulum. Aliquam lacus ipsum, mattis sed bibendum sit amet, aliquet sit amet mauris. Proin dapibus mattis nisi, nec tempus turpis pretium et. Aliquam aliquam luctus nisl et fermentum. Sed in eleifend ex, ac ultrices magna. Curabitur bibendum, massa eu auctor convallis, nulla odio tincidunt mauris, eget luctus odio leo sit amet quam. In convallis urna vel mauris sollicitudin elementum. Proin eu orci tellus. Nunc hendrerit sodales ex, ac porttitor urna viverra sed. Curabitur sed justo nibh. Etiam ut feugiat erat. Morbi pretium pharetra diam, id fringilla velit ultrices in.",
        views: 300004,
        description:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
        comments: 23,
        period_start: "23.04.2020",
        period_end: "25.04.2020",
        color: "white",
        background_color: "rgba(18, 0, 0, 0.8)",
        background_img:
          "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
        author: {
          id: 2,
          username: "Author",
          avatar:
            "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
        },
        tegs: [
          {
            id: 1,
            text: {
              en: "Moscow",
              ru: "Москва",
            },
            color: "#F3CDDB",
          },
          {
            id: 2,
            text: {
              en: "Mary Kury",
              ru: "Мария",
            },
            color: "#B0EADF",
          },
          {
            id: 5,
            text: {
              en: "Moscow",
              ru: "Москва",
            },
            color: "#F3CDDB",
          },
          {
            id: 6,
            text: {
              en: "Mary Kury",
              ru: "Мария",
            },
            color: "#B0EADF",
          },
          {
            id: 7,
            text: {
              en: "Mary Kury",
              ru: "Мария",
            },
            color: "#B0EADF",
          },
          {
            id: 8,
            text: {
              en: "Mary Kury",
              ru: "Мария",
            },
            color: "#B0EADF",
          },
        ],
        date_added: "21.04.2020",
        title: "article 1",
        rating: 5,
      },
      shorten: true,
      display: "none",
      header: "",
      changed: " (изменено)",
    };
  },
};
</script>

<style scoped lang="scss">
@import "../assets/scss/article.scss";
</style>
