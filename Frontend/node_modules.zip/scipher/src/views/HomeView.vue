<template>
  <div>
    <MainHeader color="#0033ff" header="Scipher" />
    <div class="home">
      <div class="left">
        <h3>Популярные теги</h3>
        <MainTeg :tegs="tegs" />
        <h3>Новости</h3>

        <h3>Статьи, популярные на этой неделе</h3>
        <ShortenedArticle
          v-for="article in popular_articles"
          :key="article.id"
          :article="article"
        />
      </div>
      <div class="right">

        <div class="rating_container">
          <h3>Лучшие пользователи</h3>
          <ShortenedUser v-for="user in users" :key="user.id" :user="user" />
        </div>
        <div class="rating_container">
          <h3>Последние статьи</h3>
          <ShortenedArticle
            v-for="article in latest_articles"
            :key="article.id"
            :article="article"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import MainTeg from "@/components/MainTeg.vue";
import MainHeader from "@/components/MainHeader.vue";
import ShortenedArticle from "../components/ShortenedArticle.vue";
import ShortenedUser from "../components/ShortenedUser.vue";


export default {
  name: "HomeView",
  components: {
    MainTeg,
    MainHeader,
    ShortenedArticle,
    ShortenedUser,

  },
  created() {
    this.updateMainTegs();
  },
  methods: {
    updateMainTegs() {
      // this.axios.get("http://192.168.88.55:8000/users").then((response) => {
      //   console.log(response.data);
      // });
    },
  },
  data() {
    return {
      tegs: [
        {
          id: 1,
          text: {
            en: "Moscow",
            ru: "Москва",
          },
          background_color: "#F3CDDB",
          text_color: "black",
        },
        {
          id: 2,
          text: {
            en: "Mary Kury",
            ru: "Мария",
          },
          background_color: "#B0EADF",
          text_color: "black",
        },
      ],
      news: [
        { id: 1, text: "asdad" },
        { id: 2, text: "asdad" },
      ],
      users: [
        {
          id: 1,
          text_color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          avatar: "https://w-dog.ru/wallpapers/0/62/349856802100204/zolotoj-bereg-okean-avstraliya-oteli-more-gorod.jpg",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          username: "user 1",
          user_rating: 4,
          system_rating: 5.98,
        },
        {
          id: 2,
          text_color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          username: "user 2",
          user_rating: 3,
          system_rating: 4,
        },
      ],
      popular_articles: [
        {
          id: 1,
          views: 300004,
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            username: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
          ],
        },
        {
          id: 2,
          views: 300004,
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            username: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
          ],
        },
        {
          id: 3,
          views: 300004,
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            username: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              background_color: "#F3CDDB",
              text_color: "black",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              background_color: "#B0EADF",
              text_color: "black",
            },
          ],
        },
      ],
      latest_articles: [
        {
          id: 3,
          author: { id: 2, username: "Author" },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
          ],
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
        },
        {
          id: 2,
          author: { id: 1, name: "Author2" },
          tegs: [
            {
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
          ],
          date_added: "13.12.2020",
          title: "article 3",
          rating: 4,
        },
        {
          id: 3,
          author: { id: 3, name: "Author3" },
          tegs: [
            {
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
          ],
          date_added: "13.12.2020",
          title: "article 3",
          rating: 4,
        },
      ],
    };
  },
};
</script>

<style scoped  lang="scss">
@import "../assets/scss/home.scss";
</style>
