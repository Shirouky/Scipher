<template>
  <div>
    <MainHeader color="#0033ff" header="Scipher" />
    <div class="home">
      <h3>Найденные статьи</h3>
      <ShortenedArticle
        v-for="article in articles"
        :key="article.id"
        :article="article"
      />
    </div>
  </div>
</template>


<script>
// @ is an alias to /src
import MainHeader from "@/components/MainHeader.vue";
import ShortenedArticle from "@/components/ShortenedArticle.vue";

export default {
  name: "SearchView",
  components: {
    MainHeader,
    ShortenedArticle,
  },
  created() {
    // console.log("Params: ", this.$route.params);
    // this.params = this.$route.params;
    // console.log(this.info)
  },
  data() {
    return {
      params: [],
      articles: [
        {
          id: 1,
          views: 300004,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          comments: 23,
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            name: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
          ],
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
        },
        {
          id: 2,
          views: 300004,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          comments: 23,
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            name: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
          ],
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
        },
        {
          id: 3,
          views: 300004,
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eget lobortis sapien. Donec nisl arcu, efficitur et ullamcorper sed, laoreet ut mi. Integer congue eu arcu ac fringilla. Cras in eleifend sem, eget venenatis risus. Nam non iaculis leo, nec ullamcorper odio. Duis sit amet arcu sed velit feugiat aliquam id sed ex. Ut mollis quam mollis congue ullamcorper. Pellentesque vitae lectus sagittis lacus auctor scelerisque. Curabitur in dui blandit, ultricies enim quis, porttitor augue. Aliquam efficitur non diam ut ullamcorper. Suspendisse molestie nec nisl vitae mattis. Duis posuere, sapien quis interdum mattis, ante dolor interdum ante, sit amet tempor risus ligula quis erat. Sed metus justo, blandit non purus quis, consectetur faucibus dolor.",
          comments: 23,
          period_start: "23.04.2020",
          period_end: "25.04.2020",
          color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          author: {
            id: 2,
            name: "Author",
            avatar:
              "https://million-wallpapers.ru/wallpapers/5/51/455458761658281/avatar-2-nejtiri-2017.jpg",
          },
          tegs: [
            {
              id: 1,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 2,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 5,
              text: {
                en: "Moscow",
                ru: "Москва",
              },
              color: "#F3CDDB",
            },
            {
              id: 6,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 7,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
            {
              id: 8,
              text: {
                en: "Mary Kury",
                ru: "Мария",
              },
              color: "#B0EADF",
            },
          ],
          date_added: "21.04.2020",
          title: "article 1",
          rating: 5,
        },
      ],
    };
  },
};
</script>

<style scoped lang="scss" src="../assets/scss/search_view.scss"></style>
