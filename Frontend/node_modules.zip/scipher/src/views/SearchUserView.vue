<template>
  <div>
    <MainHeader color="#0033ff" header="Scipher" />
    <div class="home">
      <h3>Найденные пользователи</h3>
      <div class="container">
        <ShortenedUser v-for="user in users" :key="user.id" :user="user" />
      </div>
    </div>
  </div>
</template>


<script>
// @ is an alias to /src
import MainHeader from "@/components/MainHeader.vue";
import ShortenedUser from "@/components/ShortenedUser.vue";

export default {
  name: "SearchView",
  components: {
    MainHeader,
    ShortenedUser,
  },
  data() {
    return {
      users: [
        {
          id: 1,
          text_color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          avatar:
            "https://w-dog.ru/wallpapers/0/62/349856802100204/zolotoj-bereg-okean-avstraliya-oteli-more-gorod.jpg",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          username: "user 1",
          rating: 4,
        },
        {
          id: 2,
          text_color: "white",
          background_color: "rgba(18, 0, 0, 0.8)",
          background_img:
            "url(https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg)",
          username: "user 2",
          user_rating: 3,
          system_rating: 4,
        },
      ],
    };
  },
};
</script>

<style scoped lang="scss" src="../assets/scss/search_view.scss"></style>
