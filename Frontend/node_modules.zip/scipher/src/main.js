import Vue from 'vue'
import App from './App.vue'
import VueCookies from 'vue-cookies'
import router from './router'
import axios from 'axios'
import VueAxios from 'vue-axios'
import CKEditor from 'ckeditor4-vue'

import { library } from '@fortawesome/fontawesome-svg-core'
import { faTrash, faEye, faPlus, faTimes, faSearch,faEllipsis, faCaretUp, faCaretDown, faMagnifyingGlass, faShare } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

library.add(faTrash, faEye, faPlus, faTimes, faSearch, faEllipsis, faCaretDown, faMagnifyingGlass, faCaretUp, faShare)

Vue.component('font-awesome-icon', FontAwesomeIcon)

Vue.use(CKEditor);
Vue.use(VueAxios, axios);
Vue.use(VueCookies);

Vue.config.productionTip = false


new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
