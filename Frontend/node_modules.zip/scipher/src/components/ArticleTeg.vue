<template>
  <div class="tegs">
    <div
      v-for="teg in tegs_display"
      :key="teg.id"
      class="teg"
      :style="{ 'background-color': teg.background_color }"
    >
      <a
        :style="{ color: teg.text_color }"
        @click="$router.push('/teg/' + teg.id)"
      >{{ teg.text["en"] }}</a>
      <font-awesome-icon v-if ="edit_mode" @cilck="deleteTeg(teg)" icon="fa-solid fa-trash" />
    </div>
    <font-awesome-icon v-if="(tegs.length > len) && (!edit_mode)" @click="changeDisplay" icon="fa-solid fa-ellipsis" />
    <font-awesome-icon v-if="!edit_mode" @click="edit_mode = true" icon="fa-solid fa-trash" />
    <font-awesome-icon v-if="edit_mode" @click="edit_mode = false" icon="fa-solid fa-eye" />
  </div>
</template>

<script>
export default {
  name: "ArticleTeg",
  props: {
    tegs: Array
  },
  mounted() {
    this.changeDisplay();
  },
  methods: {
    deleteTeg(teg){
      console.log("asdfasd")
      this.$parent.deleteTeg(teg)
      console.log("asdfasd")
    },
    changeDisplay() {
      if (this.shorten && !this.edit_mode) {
        this.tegs_display = this.tegs.slice(0, this.len);
      } else {
        this.tegs_display = this.tegs;
      }
      this.shorten = !this.shorten;
    }
  },
  data() {
    return {
      tegs_display: [],
      edit_mode: false,
      shorten: true,
      len: 5
    };
  }
};
</script>


<style scoped lang="scss" src="../assets/scss/article_teg.scss"></style>
