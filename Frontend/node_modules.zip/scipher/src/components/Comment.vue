<template>
  <div class="comment_container">
    <div class="left">
      <font-awesome-icon icon="fa-solid fa-caret-up" />
      <p v-if="comment.likes < 0" class="red">{{ comment.likes }}</p>
      <p v-else class="green">{{ comment.likes }}</p>
      <font-awesome-icon icon="fa-solid fa-caret-down" />
    </div>
    <div class="right">
      <div class="flex">
        <div class="header">
          <img
            class="avatar"
            :src="comment.author.avatar"
            @click="$router.push('/user/' + comment.author.id)"
          />
          <p class="author" @click="$router.push('/user/' + comment.author.id)">
            {{ comment.author.username }}
          </p>
          <p>{{ comment.date_added }}</p>
        </div>
        <div class="article" v-if="comment.article" @click="$router.push('/article/' + comment.article.id)">
          <a>
            {{ comment.article.title }}
          </a>
          <font-awesome-icon icon="fa-solid fa-share" />
        </div>
      </div>
      <div v-if="comment.likes < -20">
        <p v-if="!display" @click="display = true" class="hidden">
          Комментарий скрыт из-за низкого рейтинга. Показать?
        </p>
        <p v-else>{{ comment.text }}</p>
      </div>
      <p v-else>{{ comment.text }}</p>

      <font-awesome-icon icon="fa-solid fa-share" />
    </div>
  </div>
</template>

<script>
export default {
  name: "BaseComment",
  props: {
    comment: Object,
  },
  methods: {},
  data() {
    return {
      display: false,
    };
  },
};
</script>


<style scoped lang="scss" src="../assets/scss/comment.scss"></style>
