<template>
  <header id="masthead" class="scrolled">
    <div class="container">
      <h1 id="shadow">Scipher</h1>
      <h2 id="title" @click="$router.push('/')">Scipher</h2>
      <nav>
        <Search />
        <div class="margin">
          <UserMenu v-if="user.id" :user="user" />
          <div v-else class="login_container">
            <strong class="login">Login</strong>
            <ul class="submenu">
              <li>
                <p v-show="error_message">Неправильный пароль или логин</p>
              </li>
              <li>
                <input v-model="login" placeholder="Login" />
              </li>
              <li>
                <input v-model="password" placeholder="Password" />
              </li>
              <li>
                <button @click="userLogin()">Login</button>
              </li>
            </ul>
            <a @click="$router.push('/register')">Register</a>
          </div>
        </div>
      </nav>
    </div>
  </header>
</template>

<script>
import Search from "@/components/Search.vue";
import UserMenu from "@/components/UserMenu.vue";

export default {
  name: "HeadComponent",
  components: {
    Search,
    UserMenu
  },
  created() {
    this.userLogin();
  },
  methods: {
    getUserData() {
      console.log(this.$cookies.get("id"))
      if (this.$cookies.get("id") != '') {
        // this.axios
        //   .get("/user/", {
        //     params: {
        //       id: this.$cookies.id,
        //     },
        //   })
        //   .then(function (response) {
        // if (response.data != null) {
        //   this.user = response.data;
        //   this.$cookies.set("id", this.user.id);
        // } else {
        //   this.error_message = true;
        // }
        //   })
        //   .catch(function (error) {
        //     console.log(error);
        //   });
        this.user = {
          id: 1,
          avatar:
            "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
          username: "sdfsdf"
        };
      }
    },
    userLogin() {
      // this.axios
      //   .get("/user/login", {
      //     params: {
      //       login: this.login,
      //       password: this.password,
      //     },
      //   })
      //   .then(function (response) {
      // if (response.data != null) {
      //   this.user = response.data;
      //   this.$cookies.set("id", this.user.id);
      // } else {
      //   this.error_message = true;
      // }
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
      this.$cookies.set("id", 1);

      this.user = {
        id: 1,
        avatar:
          "https://www.sunhome.ru/i/wallpapers/163/alberta-banf-kanada.1920x1200.jpg",
        username: "sdfsdf"
      };
    }
  },
  data() {
    return {
      login: "",
      password: "",
      error_message: false,
      user: {}
    };
  }
};
</script>
<style scoped lang="scss" src="../assets/scss/header.scss"></style>