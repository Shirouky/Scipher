<template>
  <div
    class="container"
    :style="{ backgroundColor: article.background_color, color: article.color }"
  >
    <div
      class="background"
      :style="{ backgroundImage: article.background_img }"
    >
      <div class="upper">
        <div class="left_side">
          <span class="header">
            <img
              class="avatar"
              :src="article.author.avatar"
              @click="$router.push('/user/' + comment.author.id)"
            />
            <p
              @click="$router.push('/user/' + article.author.id)"
              class="author"
            >
              {{ article.author.username }}
            </p>
            <p>{{ article.date_added }}</p>
            <font-awesome-icon icon="fa-solid fa-eye" />
            <p class="views">{{ article.views }}</p>
          </span>
          <h5 @click="$router.push('/article/' + article.id)" class="title">
            {{ article.title }}
          </h5>
        </div>
        <div class="rating_container">
          <div class="rating">
            <p>{{ article.rating }}</p>
          </div>
        </div>
      </div>
    </div>

    <div class="description">
      <div class="tegs_container">
        <div class="tegs">
          <ArticleTeg :tegs="article.tegs" />
        </div>
        <div class="period" v-if="article.period_start">
          <p>
            {{ article.period_start }}
            <br />
            <span v-if="article.period_end">
              -
              <br />
              {{ article.period_end }}
            </span>
          </p>
        </div>
      </div>
      <p>{{ article.description }}</p>
    </div>
  </div>
</template>

<script>
import ArticleTeg from "@/components/ArticleTeg.vue";

export default {
  name: "ShortenedArticle",
  props: {
    article: Object,
  },
  components: { ArticleTeg },
};
</script>


<style scoped lang="scss" src="../assets/scss/shortened_article.scss"></style>
