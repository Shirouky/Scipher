<template>
  <div class="search-box">
    <font-awesome-icon @click="openSearch()" icon="fa-solid fa-search" />
    <div v-if="opened" class="search_container" id="search">
      <div class="search_line">
        <input
          v-show="!open_menu"
          type="text"
          class="input-search"
          placeholder="Type to Search..."
          v-model="params.title"
          @keyup.enter="submit"
        />
        <font-awesome-icon v-show="!open_menu" @click="submit" icon="fa-solid fa-search" />
        <font-awesome-icon @click="closeSearch()" icon="fa-solid fa-times" class="closeBtn" />
      </div>
      <button class="open_menu" @click="open_menu = !open_menu">Расширенный поиск</button>
      <div v-show="open_menu" class="full_search">
        <h3>По словам</h3>
        <input
          type="text"
          class="input-search"
          placeholder="Укажите название"
          v-model="params.title"
        />
        <input
          type="text"
          class="input-search"
          placeholder="Укажите ключевые слова"
          v-model="params.keywords"
        />
        <h3>По тегам</h3>
        <h4>Обязательно включать ('и'):</h4>
        <div class="tegs">
          <ArticleTeg :tegs="tegsAnd" />
        </div>
        <input
          v-on:keyup="searchTeg"
          type="text"
          class="input-search"
          placeholder="Укажите тег"
          v-model="tegAnd"
        />
        <ul class="submenu">
          <li v-for="teg in tegs" :key="teg.id">
            <p @click="addAndTeg(teg)">{{ teg.text["en"] }}</p>
          </li>
        </ul>
        <!-- <h4>Включить один или более из списка ('или'):</h4>
        <div v-for="(or, index) in ors" :key="index">
          <div class="tegs">
            <ArticleTeg :tegs="or" />
          </div>
          <input
            v-on:keyup="searchTeg"
            type="text"
            class="input-search"
            placeholder="Укажите тег"
            v-model="tegOr"
          />
          <ul class="submenu">
            <li v-for="teg in tegs" :key="teg.id">
              <p @click="addOrTeg(teg)">{{ teg.text["en"] }}</p>
            </li>
          </ul>
        </div>
        <h4>Не включать ('и не'):</h4>
        <div class="tegs">
          <ArticleTeg :tegs="tegsAnd" />
        </div>
        <input
          v-on:keyup="searchTeg"
          type="text"
          class="input-search"
          placeholder="Укажите тег"
          v-model="tegAnd"
        />
        <ul class="submenu">
          <li v-for="teg in tegs" :key="teg.id">
            <p @click="addAndTeg(teg)">{{ teg.text["en"] }}</p>
          </li>
        </ul>
      --></div>
    </div>
  </div>
</template>

<script>
import ArticleTeg from "@/components/ArticleTeg.vue";

export default {
  name: "SearchComponent",
  components: {
    ArticleTeg
  },
  methods: {
    deleteTeg(index){
      console.log(index)
    },
    closeSearch() {
      document.body.style.overflow = "scroll";
      this.open_menu = false;
      this.opened = false;
    },
    openSearch() {
      document.body.style.overflow = "hidden";
      this.opened = true;
    },
    searchTeg() {
      console.log(this.tegAnd);
    },
    addAndTeg(teg) {
      this.tegsAnd = [...this.tegsAnd, teg];
      this.params.and.push(teg.id);
      console.log(this.tegsAnd);
    },
    submit() {
      this.$router.push({ path: "/search/article", query: this.params });
    }
  },
  data() {
    return {
      tegsAnd: [
        {
          id: 1,
          text: {
            en: "Moscow",
            ru: "Москва"
          },
          background_color: "#F3CDDB",
          text_color: "black"
        }
      ],
      tegAnd: "",
      tegOr: "",
      tegs: [
        {
          id: 1,
          text: {
            en: "Moscow",
            ru: "Москва"
          },
          background_color: "#F3CDDB",
          text_color: "black"
        },
        {
          id: 2,
          text: {
            en: "Mary Kury",
            ru: "Мария"
          },
          background_color: "#B0EADF",
          text_color: "black"
        }
      ],
      ors: [
        [
          {
            id: 1,
            text: {
              en: "Moscow",
              ru: "Москва"
            },
            background_color: "#F3CDDB",
            text_color: "black"
          },
          {
            id: 2,
            text: {
              en: "Mary Kury",
              ru: "Мария"
            },
            background_color: "#B0EADF",
            text_color: "black"
          }
        ],
        [
          ({
            id: 1,
            text: {
              en: "Moscow",
              ru: "Москва"
            },
            background_color: "#F3CDDB",
            text_color: "black"
          },
          {
            id: 2,
            text: {
              en: "Mary Kury",
              ru: "Мария"
            },
            background_color: "#B0EADF",
            text_color: "black"
          })
        ]
      ],
      opened: false,
      open_menu: false,
      params: {
        title: "",
        keywords: "",
        or: [
          [4, 5, 1],
          [4, 5, 6]
        ],
        and: [[1, 2, 3]]
      }
    };
  }
};
</script>


<style scoped lang="scss" src="../assets/scss/search.scss"></style>
