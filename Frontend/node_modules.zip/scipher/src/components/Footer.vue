<template>
  <footer>
    <p>© 2022 Scipher</p>
  </footer>
</template>

<script>
export default {
  name: "FooterComponent",
  components: {},
  props: {},
  methods: {},
  data() {
    return {};
  },
};
</script>


<style scoped lang="scss" src="../assets/scss/footer.scss"></style>
