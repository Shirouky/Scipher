<template>
  <div class="tegs">
    <div
      v-for="teg in tegs"
      :key="teg.id"
      class="teg"
      :style="{ 'background-color': teg.background_color }"
    >
      <p :style="{ 'color': teg.text_color }">{{ teg.text["en"] }}</p>
      <font-awesome-icon icon="fa-solid fa-plus" />
    </div>
  </div>
</template>

<script>
export default {
  name: "MainTeg",
  props: {
    tegs: Array,
  },
};
</script>


<style scoped lang="scss">
@import "../assets/scss/_variables.scss";

.tegs {
  @include flex(space-between);

  .teg {
    margin-right: 10px;
    width: 200px;
    height: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    box-sizing: border-box;

    p {
      text-align: center;
      font-weight: 500;
      font-size: 15px;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }
}
</style>
