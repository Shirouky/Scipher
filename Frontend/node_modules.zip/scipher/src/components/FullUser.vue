<template>
  <div>
    <div class="big_container">
      <div
        class="background"
        :style="{
          backgroundImage: user.background_img,
          color: user.text_color,
        }"
      >
        <div class="upper">
          <div class="left_side">
            <span class="header">
              <img
                class="avatar"
                :src="user.avatar"
                @click="$router.push('/user/' + user.id)"
              />
              <h5 @click="$router.push('/user/' + user.id)" class="title">
                {{ user.username }}
              </h5>
            </span>
          </div>
          <div class="rating_container">
            <div class="rating">
              <p>{{ user.rating }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ShortenedUser",
  props: {
    user: Object,
  },
};
</script>


<style scoped lang="scss" src="../assets/scss/shortened_article.scss">
@import "../assets/scss/user_profile.scss";
</style>
