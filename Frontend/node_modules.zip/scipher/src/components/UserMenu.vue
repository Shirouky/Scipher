<template>
  <div>
    <div class="avatar" @click="openNav()">
      <p @click="$router.push('/user/' + user.id)">{{ user.username }}</p>
      <img :src="user.avatar" />
      <font-awesome-icon icon="fa-solid fa-caret-down" />
    </div>
    <div id="myNav" class="overlay closed">
      <font-awesome-icon @click="closeNav()" icon="fa-solid fa-times" class="closeBtn"/>
      <div class="overlay-content">
        <div class="wrapper">
          <a @click="$router.push('/user/' + user.id)">Профиль</a>
        </div>
        <div class="wrapper">
          <a>Новости</a>
        </div>
        <div class="wrapper">
          <a class="exit">Выход</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "UserMenu",
  props: {
    user: Object,
  },
  methods: {
    openNav() {
      const nav = document.getElementById("myNav");
      nav.classList.add("opened");
      nav.classList.remove("closed");
    },

    closeNav() {
      const nav = document.getElementById("myNav");
      nav.classList.add("closed");
      nav.classList.remove("opened");
    },
  },
  data() {
    return {};
  },
};
</script>


<style scoped lang="scss">
@import "../assets/scss/user_menu.scss";
</style>
