<template>
  <div class="container">
    <div class="push-pop loader">
      <div></div>
      <div></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BaseLoader",
};
</script>


<style>
.hide {
  height: 100%;
  overflow: hidden;
}
</style>
<style scoped lang="scss" src="../assets/scss/loader.scss"/>