<template>
  <div id="app">
    <!-- <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </nav> -->
    <router-view/>
    <Footer />
  </div>
</template>

<script>
import Footer from "@/components/Footer.vue";

 
export default {
  name: "App",
  components: {
    Footer,
  },
  created(){
  },
  methods: {
    getUserData() {
      this.axios.get('https://randomuser.me/api/')
      .then((responce) => {
          const res = responce.data.results[0];
          this.username = res.login.username;
          this.name = res.name.first;
          this.surname = res.name.last;
          this.location = res.location.city;
          this.mail = res.email;
          this.phone = res.phone;
      })
    },
  },
  data() {
    return {
      language: "ru"
    };
  },
};
</script>

<style lang="scss">

body, p{
  margin: 0;
  padding: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

font-awesome-icon{
  cursor: pointer;
  font-size: 18px;
}
</style>
